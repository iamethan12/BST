def insert(root, key):
    """Insert a new key into the BST with the given root

    :param root: the list representing the BST
    :param key: the key to insert

    :return: list representing the new BST
    """


def search(root, key):
    """Search for a target key in the BST with the given root.

    :param root: the list representing the BST
    :param key: the key to search for

    :return whether or not key was found
    :rtype Boolean
    """


def sort(data):
    """Sort the data into a new BST
    :param data: an unsorted list of data to be sorted in a BST

    :return a sorted BST
    :rtype list
    """


def main():
    print('Use your main function as you see fit')


if __name__ == '__main__':
    main()
