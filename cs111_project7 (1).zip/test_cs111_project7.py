"""
Test functions in project 9
    Instructions: edit first line from NAMES_cs111_project9 import insert, search, sort
                    replace NAMES_cs111_project9 with the name of your .py file
                    This test file should be saved into the same folder as your project 9 .py file
Author: Prof. Stacey Truex
Date: November 2021
CS111-02, Fall 2021
"""


from Solution_cs111_project7 import insert, search, sort
import os
import os.path
import pickle


def test_insert():
    """
    Test the insert function in your project 9 program

    :return: None
    """
    assert insert([], 50) == [50, [], []], 'failed to insert into empty BST'
    print('Passed insert Test 1')
    assert insert([50, [], []], 10) == [50, [10, [], []], []], 'failed to insert smaller value'
    print('Passed insert Test 2')
    assert insert([50, [], []], 80) == [50, [], [80, [], []]], 'failed to insert larger value'
    print('Passed insert Test 3')
    assert insert([50, [], [80, [], []]], 70) == [50, [], [80, [70, [], []], []]], 'failed to insert second level'
    print('Passed insert Test 4')

    print("-"*20)
    print("Begin insertion error tests")
    print("-"*20)
    try:
        err = 'failed to validate key provided'
        assert insert([], None) == [], err
        print('Passed insert Test 5')
        err = 'failed to validate BST provided'
        assert insert(None, 1) == [], err
        print('Passed insert Test 6')
        err = 'failed to validate BST type'
        assert insert('string input', 1) == [], err
        print('Passed insert Test 7')
        err = 'failed to validate key type'
        assert insert([], 'string input') == [], err
        print('Passed insert Test 8')
    except BaseException:
        print(err)
    print("-" * 20)
    print("End insertion error tests")
    print("-" * 20)

    print('\nPassed all insert tests!\n\n\n')


def test_sort():
    """
    Test the sort function in your project 9 program

    :return: None
    """
    assert sort([]) == [], 'failed to sort empty list'
    print('Passed sort Test 1')
    assert sort([50]) == [50, [], []], 'failed to sort single item list'
    print('Passed sort Test 2')
    assert sort([50, 10]) == [50, [10, [], []], []], 'failed to sort 50, 10'
    print('Passed sort Test 3')
    assert sort([50, 80]) == [50, [], [80, [], []]], 'failed to sort 50, 80'
    print('Passed sort Test 4')
    assert sort([50, 80, 70]) == [50, [], [80, [70, [], []], []]], 'failed to sort 50, 80, 70'
    print('Passed sort Test 5')

    print("-" * 20)
    print("Begin sorting error tests")
    print("-" * 20)
    try:
        err = 'failed to validate data provided'
        assert sort(None) == [], err
        print('Passed sort Test 6')
        err = 'failed to validate data type (string)'
        assert sort('string') == [], err
        print('Passed sort Test 7')
        err = 'failed to validate data type (int)'
        assert sort(8) == [], err
    except BaseException:
        print(err)
    print("-" * 20)
    print("End sorting error tests")
    print("-" * 20)

    print('\nPassed all sort tests!\n\n\n')


def test_search():
    """
    Test the search function in your project 9 program

    :return: None
    """
    bst = [50, [], [80, [70, [], []], []]]
    assert search(bst, 50), 'failed to find root (50)'
    print('Passed search Test 1')
    assert search(bst, 80), 'failed to find 80'
    print('Passed search Test 2')
    assert search(bst, 70), 'failed to find 70'
    print('Passed search Test 3')
    assert not search(bst, 5), 'found data not in BST (5)'
    print('Passed search Test 4')

    print("-" * 20)
    print("Begin search error tests")
    print("-" * 20)
    try:
        err = 'failed to validate BST provided'
        assert not search(None, 80), err
        print('Passed search Test 5')
        err = 'failed to validate key provided'
        assert not search(bst, None), err
        print('Passed search Test 6')
        err = 'failed to validate key type'
        assert not search(bst, 'string input'), err
        print('Passed search Test 7')
        err = 'failed to validate BST type'
        assert not search('string input', 80), err
        print('Passed search Test 8')
    except BaseException:
        print(err)
    print("-" * 20)
    print("End search error tests")
    print("-" * 20)

    print('\nPassed all search tests!\n\n\n')


def check_file(file_name):
    """
    Verify that the test input file exists in the current folder

    :param file_name: name of the test file to verify
    :return: None
    """
    assert os.path.isfile(file_name), '{} does not exist in the same folder as this .py file'.format(file_name)
    assert os.access(file_name, os.R_OK), '{} cannot be read'.format(file_name)


def create_data_list(file_name):
    """
    Read in data from test file and create a list of numbers to provide to the sort function.

    :param file_name: test file containing the data
    :return: list of integers read in from test file
    :rtype: list
    """
    file_object = open(file_name, 'r')
    data = []
    for line in file_object:
        line_data = line.split(',')
        for x in line_data:
            data.append(int(x))
    return data


def file_tests():
    """
    Test sorting function using integers in pre-made csv files and verifying accuracy against previously saved reults

    :return: None
    """
    file_name = 'test_input_5.csv'
    result = [151302, [146177, [65493, [], []], []], [408324, [], [452024, [], []]]]
    check_file(file_name)
    data = create_data_list(file_name)
    assert sort(data) == result, 'Did not sort data in test_input_5.csv into a BST correctly'
    print('Passed file Test 1')

    file_names = ['test_input_20.csv', 'test_input_200.csv', 'test_input_2000.csv']
    result_names = ['test_20_result.pkl', 'test_200_result.pkl', 'test_2000_result.pkl']
    for i in range(len(file_names)):
        check_file(file_names[i])
        data = create_data_list(file_names[i])
        result_file = open(result_names[i], 'rb')
        result = pickle.load(result_file)
        result_file.close()
        assert sort(data) == result, 'Did not sort data in {} into a BST correctly'.format(file_names[i])
        print('Passed file Test {}'.format(i+2))

    print('\nPassed all file tests!\n\n\n')


def run_tests():
    """
    Run all tests for project 9

    :return: None
    """
    test_insert()
    test_sort()
    test_search()
    file_tests()
    print('Congrats! You passed all tests.')


run_tests()
